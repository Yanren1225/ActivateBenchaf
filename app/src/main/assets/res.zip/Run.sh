cp /storage/emulated/0/Android/data/cn.endureblaze.activatebenchaf/files/daemon /data/local/tmp
chmod 777 /data/local/tmp/daemon
cd /data/local/tmp/
./daemon &
echo "执行成功"